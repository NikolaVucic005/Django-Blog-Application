from django.urls import path
from . import views

app_name = "posts"

urlpatterns = [
    path("",views.posts, name="main"),
    path("new-post",views.posts_new, name="posts_new"),
    path("<slug:variable>/edit", views.posts_edit, name="posts_edit"),
    path("<slug:variable>/delete", views.posts_delete, name="posts_delete"),
    path("<slug:variable>",views.posts_page, name="page"),
]