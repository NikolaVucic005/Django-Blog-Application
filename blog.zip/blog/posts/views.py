from django.shortcuts import render, redirect, get_object_or_404
from .models import Post
from django.contrib.auth.decorators import login_required
from . import forms
# Create your views here.

def posts(request):
    post = Post.objects.all()
    return render (request, "posts/posts.html", {"post":post})

def posts_page(request, variable):
    page = Post.objects.get(slug=variable)
    return render (request, "posts/posts_page.html", {"page":page})

@login_required (login_url = "/users/login/")
def posts_new(request):
    if request.method == "POST":
        form = forms.NewPost(request.POST, request.FILES)
        if form.is_valid():
            users = form.save(commit=False)
            users.creator = request.user
            users.save()
            return redirect ("posts:main")
    else:
        form = forms.NewPost()
    return render (request, "posts/posts_new.html", {"form":form})

@login_required(login_url="/users/login/")
def posts_edit(request, variable):
    post = get_object_or_404(Post, slug=variable, creator=request.user)
    if request.method == "POST":
        form = forms.NewPost(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect("posts:page", variable=post.slug)
    else:
        form = forms.NewPost(instance=post)
    return render(request, "posts/posts_edit.html", {"post": post, "form":form})

# POST DELETE
@login_required(login_url="/users/login/")
def posts_delete(request, variable):
    post = get_object_or_404(Post, slug=variable, creator=request.user)
    if request.method == "POST":
        post.delete()
        return redirect("posts:main")
    return render(request, "posts/posts_delete.html", {"post": post})


